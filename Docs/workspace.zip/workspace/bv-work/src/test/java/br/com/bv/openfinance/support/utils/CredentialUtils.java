package br.com.bv.openfinance.support.utils;

public class CredentialUtils {
    public static String credencial(String credencial) {
        return System.getenv(credencial);
    }
}

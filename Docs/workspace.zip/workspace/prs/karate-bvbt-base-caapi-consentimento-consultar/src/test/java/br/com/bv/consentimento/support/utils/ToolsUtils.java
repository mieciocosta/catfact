package br.com.bv.consentimento.support.utils;

import javax.crypto.Cipher;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class ToolsUtils {

    public static void await(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        }catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public static String remove(String text, String caracter) {
        return text.replaceAll(caracter, "");
    }

    public static String replace(String text, String velho, String novo) {
        return text.replaceAll(velho, novo);
    }

    public static PublicKey convert(String publicKey) throws NoSuchAlgorithmException, InvalidKeySpecException {
        byte[] pKBytes = Base64.getDecoder().decode(publicKey);

        KeyFactory keyFactory = KeyFactory.getInstance("RSA");

        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(pKBytes);

        return keyFactory.generatePublic(keySpec);
    }

    public static String encrypt(String cvv, PublicKey hash) throws Exception {
        byte[] cvvToBytes = cvv.getBytes();
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, hash);
        byte[] encryptedBytes = cipher.doFinal(cvvToBytes);
        return encode(encryptedBytes);
    }

    public static String encode(byte[] data) {
        return Base64.getEncoder().encodeToString(data);
    }
}

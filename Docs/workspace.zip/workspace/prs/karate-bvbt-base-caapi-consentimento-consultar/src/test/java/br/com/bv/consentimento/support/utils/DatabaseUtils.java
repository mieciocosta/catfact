package br.com.bv.consentimento.support.utils;

import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 * Connects to the database.
 */
public class DatabaseUtils {
    private static final Logger logger = LoggerFactory.getLogger(DatabaseUtils.class);

    /**
     * This method is the one that connects to the database. It is only necessary to pass the url,
     * the username, password and driverClassName
     */
    private final JdbcTemplate jdbc;
    public DatabaseUtils(Map<String, Object> config) {
        String url = (String) config.get("url");
        String username = (String) config.get("username");
        String password = (String) config.get("password");
        String driver = (String) config.get("driverClassName");
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(driver);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        jdbc = new JdbcTemplate(dataSource);
        logger.info("init jdbc template: {}", url);
    }

    /**
     * It is used to query, passing a value
     */
    public Object readValue(String query) {
        return jdbc.queryForObject(query, Object.class);
    }

    /**
     * It is used to query a single object
     */
    public Map<String, Object> readRow(String query) {
        return jdbc.queryForMap(query);
    }

    /**
     * It is used to query a list
     */
    public List<Map<String, Object>> readRows(String query) {
        return jdbc.queryForList(query);
    }

}
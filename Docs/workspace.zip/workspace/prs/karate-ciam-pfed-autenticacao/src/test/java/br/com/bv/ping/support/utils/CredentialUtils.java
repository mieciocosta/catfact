package br.com.bv.ping.support.utils;

public class CredentialUtils {
    public static String credencial(String credencial) {
        return System.getenv(credencial);
    }
}
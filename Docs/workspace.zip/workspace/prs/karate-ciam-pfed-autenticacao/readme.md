#  Serviço de Testes automatizados [![Build Status](https://jenkins-qa.cicd.gke.bvnet.bv/buildStatus/icon?job=CIAM-PFED/karate-ciam-pfed-autenticacao/master)](https://jenkins-qa.cicd.gke.bvnet.bv/job/CIAM-PFED/job/karate-ciam-pfed-autenticacao/)

# ✔️ Projeto de Casos de Testes

Projeto responsável pela cobertura de testes do Login Simples.


## ✔️ Autores

- Time de Engenharia de SI 

## ✔️ Referência

 - [PingFederate](https://developer.pingidentity.com/en/cloud-software/pingfederate.html)
 - [Console Administrativo PingFederate](https://10.179.0.6:9999/render/pingfederate/app?service=page/login) 

## 🔨 Funcionalidades

- `Funcionalidade 1`:Cobrir as chamadar de erros e validações do Login Simples

## ✔️ Tecnologias e informações utilizadas no código

- ``Java11``
- ``Karate``
- ``Eclipse ou Intelij``


## ✔️ Rodando localmente

Clone o projeto

```bash
  git clone -b <nome da Branch> https://bitbucket.bvnet.bv/scm/ciam-pfed/karate-ciam-pfed-autenticacao.git
```

## ✔️ Documentação

 - [Confluence - Regra de Negócio](https://confluence.bvnet.bv/pages/viewpage.action?pageId=194854634)


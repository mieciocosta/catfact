# Changelog

<a name="0.0.1"></a>

## 0.0.1 (01-2024)

### Adições

- ✨ Versão inicial do desenvolvimento do Projeto [[SEGCAN-188](https://jira.bvnet.bv/browse/SEGCAN-188)]

----------------------------------------------------------------------------------------------------------------

<a name="Modelo"></a>

## Version: X.X.X (Data)

### Adições

- ✨ Breve Descrição [[<Número Card Jira>](<Link do Card Jira>)]

### Mudanças

- ⬆️ Breve Descrição [[<Número Card Jira>](<Link do Card Jira>)]

### Correções

- 🚨 Breve Descrição [[<Número Card Jira>](<Link do Card Jira>)]

### Diversos

- 📝 Breve Descrição [[<Número Card Jira>](<Link do Card Jira>)]

### Remoção

- 🔥 Breve Descrição [[<Número Card Jira>](<Link do Card Jira>)]
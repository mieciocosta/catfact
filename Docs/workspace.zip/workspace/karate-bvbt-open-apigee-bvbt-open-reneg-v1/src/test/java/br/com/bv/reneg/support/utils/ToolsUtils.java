package br.com.bv.reneg.support.utils;

public class ToolsUtils {

    public static void await(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        }catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public static String remove(String text, String caracter) {
        return text.replaceAll(caracter, "");
    }

    public static String replace(String text, String velho, String novo) {
        return text.replaceAll(velho, novo);
    }

}

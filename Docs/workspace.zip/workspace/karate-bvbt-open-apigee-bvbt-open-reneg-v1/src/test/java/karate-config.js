function fn() {
  var env = karate.env; // get system property 'karate.env'
  var config = { env: env }
  var headers = {"cache-control": "no-cache"}
  karate.configure('ssl' , true)
  if (!env) { env = 'uat'; }

  switch(env) {
    case 'qa':
      config = karate.read('classpath:br/com/bv/reneg/support/config/domain.yaml')['qa']
      break;
    case 'uat':
      config = karate.read('classpath:br/com/bv/reneg/support/config/domain.yaml')['uat']
      break;
    case 'dev':
      config = karate.read('classpath:br/com/bv/reneg/support/config/domain.yaml')['dev']
      break;
    default:
  }

  karate.log('karate.env system property was:', env);
  karate.configure('headers', headers);
  karate.configure('retry', { count: 10, interval: 5000 });
  karate.configure('ssl', { trustAll: true });
  return config;
}

